import sys
import os
from os import path
import pandas as pd
import requests
import json
import math

sys.path.append(path.dirname(path.dirname(path.dirname(os.getcwd()))))


def is_digit(x):
    x = str(x)
    try:
        x = float(x)
        return True
    except ValueError:
        return False


def get_real_track(vehicleno, start_time, end_time, version):
    """
    Des:
        获取目标车辆的起点时间 与 终点时间，返回车辆实际路径点
        PS：此处需要请求亿通平台是通的
    """
    if version == 'old':
        url = 'http://192.168.120.166:1080/custom-server/pickRide/getLocationByVehicleno'  # 旧风控版本
        payload = {"vehicleno": f"{vehicleno}", "startTime": f"{str(start_time)}", "endTime": f"{str(end_time)}"}
        headers = {"Content-Type": "application/json"}
        r = requests.post(url, data=json.dumps(payload), headers=headers)
        res = r.json()
        if res['status']:
            return res['map']['data']
        else:
            return ''
    if version == 'new':
        # 旧风控版本
        # url = 'http://192.168.120.166:1080/custom-server/pickRide/getLocationByVehicleno'
        # EP测试环境 需要把这里放到auth config
        # url = 'https://api.eptrade.cn/data/gps/cfn152/v1'
        url = 'http://192.168.120.23:8879/data/gps/cfn152/v1'
        data = {"vehicleNo": f"{vehicleno}", "startTime": f"{str(start_time)}", "endTime": f"{str(end_time)}",
                "orgCode": "31222xxxxx", "apCode": "AP_1054", "start": 1, "end": 10000}
        headers = {"Authorization": "50032276172F42A2A98418E332503921", "Content": "application/json"}
        res = requests.post(url=url, headers=headers, json=data).json()
        # print(res)
        if res['statusCode'] == 200:
            # print('get real track successfully')
            return res['reqData']['dataList']
        else:
            # print(res)
            return 'get real track failed'


def get_pred_track(begin_point, end_point):
    """
    Des: 输入起点位置终点位置 [lon, lat]，返回预估路径 json
    EXAMPLE ：
        # 洋山海关
        yangshan = '121.886239,30.876474'
        # 中国（上海）自由贸易试验区（6号门）
        shiyanqu_6 = '121.608141,31.330975'
        begin_point = '121.886239,30.876474'
        #上飞路919号 '121.860207,31.086784'
        #end_point
        大厂 '121.432914,31.30406'
    PS:此处需要请求的高德平台是通的
    """
    # key = 'aed35d17b96a34d86719dc89f3b86f8a'
    # key = '435e434ba3c0c8c9347446ce0d7183f9'
    key = '57cc40c822231d35e77c729f15a99bd9'  # 公司apikey
    g = GpsRespond(begin_point, end_point, key)
    g.get_gps_road()
    return g.predict_road_gps


class LngLatTransfer:
    # lon:经度 lat:维度
    def __init__(self):
        self.x_pi = 3.14159265358979324 * 3000.0 / 180.0
        self.pi = math.pi  # π
        self.a = 6378245.0  # 长半轴
        self.es = 0.00669342162296594323  # 偏心率平方
        pass

    def GCJ02_to_WGS84(self, gcj_lng, gcj_lat):
        '''
        实现GCJ02坐标系向WGS84坐标系的转换
        :param gcj_lng: GCJ02坐标系下的经度
        :param gcj_lat: GCJ02坐标系下的纬度
        :return: 转换后的WGS84下经纬度
        '''
        dlat = self._transformlat(gcj_lng - 105.0, gcj_lat - 35.0)
        dlng = self._transformlng(gcj_lng - 105.0, gcj_lat - 35.0)
        radlat = gcj_lat / 180.0 * self.pi
        magic = math.sin(radlat)
        magic = 1 - self.es * magic * magic
        sqrtmagic = math.sqrt(magic)
        dlat = (dlat * 180.0) / ((self.a * (1 - self.es)) / (magic * sqrtmagic) * self.pi)
        dlng = (dlng * 180.0) / (self.a / sqrtmagic * math.cos(radlat) * self.pi)
        mglat = gcj_lat + dlat
        mglng = gcj_lng + dlng
        lng = gcj_lng * 2 - mglng
        lat = gcj_lat * 2 - mglat
        return lng, lat

    def _transformlat(self, lng, lat):
        ret = -100.0 + 2.0 * lng + 3.0 * lat + 0.2 * lat * lat + \
              0.1 * lng * lat + 0.2 * math.sqrt(math.fabs(lng))
        ret += (20.0 * math.sin(6.0 * lng * self.pi) + 20.0 *
                math.sin(2.0 * lng * self.pi)) * 2.0 / 3.0
        ret += (20.0 * math.sin(lat * self.pi) + 40.0 *
                math.sin(lat / 3.0 * self.pi)) * 2.0 / 3.0
        ret += (160.0 * math.sin(lat / 12.0 * self.pi) + 320 *
                math.sin(lat * self.pi / 30.0)) * 2.0 / 3.0
        return ret

    def _transformlng(self, lng, lat):
        ret = 300.0 + lng + 2.0 * lat + 0.1 * lng * lng + \
              0.1 * lng * lat + 0.1 * math.sqrt(math.fabs(lng))
        ret += (20.0 * math.sin(6.0 * lng * self.pi) + 20.0 *
                math.sin(2.0 * lng * self.pi)) * 2.0 / 3.0
        ret += (20.0 * math.sin(lng * self.pi) + 40.0 *
                math.sin(lng / 3.0 * self.pi)) * 2.0 / 3.0
        ret += (150.0 * math.sin(lng / 12.0 * self.pi) + 300.0 *
                math.sin(lng / 30.0 * self.pi)) * 2.0 / 3.0
        return ret


class GpsRespond(object):
    def __init__(self, begin_point, end_point, key):
        b = begin_point.split(',')[0] + '%2C' + begin_point.split(',')[1]
        e = end_point.split(',')[0] + '%2C' + end_point.split(',')[1]
        # TODO 生产更换高德api端口 ，原接口地址为
        #  f'https://restapi.amap.com/v4/direction/truck?cartype=&' \
        #  f'destination={e}&height=&key={key}&load=12&number=&origin={b}&province=沪&size=4&strategy=1&width='
        self.requests_url = \
            f'http://192.168.120.114:9002/v4/direction/truck?cartype=&' \
            f'destination={e}&height=&key={key}&load=12&number=&origin={b}&province=沪&size=4&strategy=1&width='
        self.respond_content = ''
        self.predict_road_num = ''
        self.predict_road_gps = dict()

    def get_gps_road(self):
        """获取预估的GPS路径
        ：param requests_url 请求URL
        ：Return road gps point : gps点列表 [[lat, lon]]
        """
        # 这里被注释掉了，晚点需要改掉
        self.respond_content = requests.get(self.requests_url).json()
        # with open('../BDRISK_TRACK/api_res/res7.json', 'r', encoding='utf-8') as fp:
        #     self.respond_content = json.load(fp)
        self.predict_road_num = self.respond_content['data']['count']
        # print(f"prediction gps road num is {self.predict_road_num}")
        for road_num in range(0, int(self.predict_road_num)):
            self.predict_road_gps[str(road_num) + '_path'] = self._parse_gps_point(road_num)
            self.predict_road_gps[str(road_num) + '_time'] = self.respond_content['data']['route']['paths'][road_num][
                'duration']
        return self.get_gps_road

    def _parse_gps_point(self, road_num):
        pline = []
        for steps in self.respond_content['data']['route']['paths'][road_num]['steps']:
            if len(steps['polyline'].split(';')) >= 1:
                for j in steps['polyline'].split(';'):
                    lon, lat = j.split(',')
                    lon, lat = float(lon), float(lat)
                    # 这里是原本返回的!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    # TODO 记得切换！！！！(以前是lat lon，现在是lon，lat)
                    # pline.append([lat, lon])
                    #         修改返回后的lat long 顺序
                    pline.append([lon, lat])
            else:
                pline.append(steps['polyline'])

        pline = self._gps_gcj02_to_wgs84(pline)
        return pline

    @staticmethod
    def _gps_gcj02_to_wgs84(pline):
        change_pline = []
        Instance = LngLatTransfer()
        for i in pline:
            # 把pline里的经纬度从GCJ02坐标系向WGS84坐标系的转换
            lon, lat = i[0], i[1]
            result = Instance.GCJ02_to_WGS84(lat, lon)
            change_pline.append([round(result[1], 6), round(result[0], 6)])
        return change_pline


if __name__ == '__main__':
    # print(get_pred_track(begin_point='121.875658,30.868727',end_point='121.691194,31.204852'))
    print(get_real_track(vehicleno="测试00001", start_time="2020-09-14 09:04:37",
                         end_time="2020-09-14 11:04:37", version="new"))
