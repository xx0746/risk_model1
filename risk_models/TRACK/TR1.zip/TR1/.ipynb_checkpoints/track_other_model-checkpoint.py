
def track_kjkc_model():
    #------------空进空出监控对应sql------------
    sql = """
    select BIZOP_ETPS_NM, vehicle_no from (
    select b.BIZOP_ETPS_NM, b.vehicle_no ,
    row_number() over(partition by b.vehicle_no order by b.lastupdateddt desc  ) rnum
    from ods_zmxpq.port_release_bsc  b 
    inner join (
    select a.vehicle_no ,a.lastupdateddt
    from ods_zmxpq.port_release_bsc a 
    where  
     a.in_exp_type = 0 and 
    a.ie_typecd = 'E' )c
    on b.vehicle_no = c.vehicle_no
    and b.in_exp_type = 0
    and  b.IE_TYPECD  = 'I' 
    and b.lastupdateddt <= c.lastupdateddt)
    where rnum  = 1
    """
    return DataSrcOper.read_oracle(sql, database='dbods', chunk=False)
  
    
def track_pfjc_model():
    # --------- 车辆频繁进出区监控--------------  
    sql = """
    select vehicle_no, --公司名
           bizop_etps_nm, --车牌号
           cnt, --进出次数
           sysdate --当前时间 检测时间
      from (select vehicle_no,
                   bizop_etps_nm,
                   cnt,
                   row_number() over(partition by vehicle_no order by cnt desc) as row_num
              from (select distinct a.vehicle_no,
                                    a.bizop_etps_nm,
                                    count(a.vehicle_no) over(partition by a.vehicle_no) as cnt
                      from ods_zmxpq.port_release_bsc a
                     inner join ods_zmxpq.port_release_inexp_rlt b
                        on a.preent_no = b.preent_no
                     where a.in_exp_type in (3, 4) ----对应（3：分送集报， 4：区内流转） 为二线卡口
                       and b.in_exp_time >= sysdate - 1))
     group by vehicle_no, row_num, bizop_etps_nm, cnt
    having row_num <= ceil(0.05 * max(row_num))
    """
    return DataSrcOper.read_oracle(sql, database='dbods', chunk=False)

def track_yjfh_model():
    sql = """
    WITH c as
     (select bizop_etps_nm,
             HOUR24,
             count(1) as cnt,
             to_char(pass_time, 'yyyymm') as pass_time
        from (select a.bizop_etps_nm,
                     decode(a.secd_pass_time, null, TO_NUMBER(TO_CHAR(a.pass_time, 'hh24')),TO_NUMBER(TO_CHAR(a.secd_pass_time, 'hh24'))) AS HOUR24,
                     decode(a.secd_pass_time, null, a.pass_time, a.secd_pass_time) as pass_time
                from ods_zmxpq.port_release_bsc a
               inner join ods_zmxpq.port_release_rlt b
                  on a.preent_no = b.port_no
                 and a.iscurrent =1
                 and a.isdeleted = 0 
                 and b.rlt_tb_typecd <> 1
                 and b.iscurrent =1
                 and b.isdeleted = 0
               where a.Port_Iochkpt_Stucd = 2) b
       group by bizop_etps_nm, HOUR24, to_char(pass_time, 'yyyymm'))
    select bizop_etps_nm, --公司名称
           pass_time, -- 按照月统计过卡时间
           night_cnt, --夜间发送的单证数量 
           total_cnt --单证总数
      from (select bizop_etps_nm,
                   num_percent,
                   pass_time,
                   night_cnt,
                   total_cnt,
                   row_number() over(partition by pass_time order by num_percent desc) as rnum
              from (select c.bizop_etps_nm,
                           sum(nvl(d.cnt, 0)) / sum(c.cnt) as num_percent,
                           c.pass_time,
                           sum(nvl(d.cnt, 0)) as night_cnt,
                           sum(c.cnt) as total_cnt
                      from c
                      left join (select *
                                  from c
                                 where HOUR24 >= 22
                                    or HOUR24 <= 6) d
                        on c.bizop_etps_nm = d.bizop_etps_nm
                       and c.pass_time = d.pass_time
                       and c.HOUR24 = d.HOUR24
                     group by c.bizop_etps_nm, c.pass_time))
     group by bizop_etps_nm, rnum, pass_time, night_cnt, total_cnt
    having rnum <= ceil (0.1 * max(rnum))
    """

    return DataSrcOper.read_oracle(sql, database='dbods', chunk=False)

class TrackOtherModel(object):
    def __init__(self):
        pass
    
    @classmethod
    def track_other_model(clf, if_exists='append'):
        now = datetime.datetime.now()
        try:
            kjkc_res = track_kjkc_model()
            kjkc_res = kjkc_res.rename(columns={'BIZOP_ETPS_NM': 'CORP_NAME'})
            kjkc_res['CHECK_TIME'] = now
            DataMxOper.save2oracle(name='MX_TRACK_KJKC', data_df=kjkc_res, if_exists=if_exists, dtype={'CHECK_TIME':'DATE'})
            logger.info('SUCCESS! Create track kjkc model')
        except Exception as e:
            logger.info('Reason:', e)
            logger.info('FAIL! Create track kjkc model')
        try:
            pfjc_res = track_pfjc_model()[['BIZOP_ETPS_NM', 'VEHICLE_NO', 'CNT']]
            pfjc_res = pfjc_res.rename(columns={'BIZOP_ETPS_NM': 'CORP_NAME', 'CNT':'WORK_NUM'})
            pfjc_res['CHECK_TIME'] = now
            DataMxOper.save2oracle(name='MX_TRACK_PFJC', data_df=pfjc_res, if_exists=if_exists, dtype={'WORK_NUM':'DECIMAL','CHECK_TIME':'DATE'})
            logger.info('SUCCESS! Create track pfjc model')
        except Exception as e:
            logger.info('Reason:', e)
            logger.info('FAIL! Create track pfjc model')
        try:
            yjfh_res = track_yjfh_model()
            yjfh_res = yjfh_res.rename(columns={'BIZOP_ETPS_NM':'CORP_NAME'})
            yjfh_res['CHECK_TIME'] = now
            yjfh_res['PASS_TIME'] = pd.to_datetime(yjfh_res['PASS_TIME'], format='%Y%m')
            DataMxOper.save2oracle(name='MX_TRACK_YJFH', data_df=yjfh_res, if_exists=if_exists, dtype={'PASS_TIME':'DATE', 'NIGHT_CNT':'DECIMAL',
                                                                         'CHECK_TIME':'DATE', 'TOTAL_CNT':'DECIMAL'})
            logger.info('SUCCESS! Create track yjfh model')
        except Exception as e:
            logger.info('Reason:', e)
            logger.info('FAIL! Create track yjfh model')
        